////<reference path="angular.min.js"/>

var myApp = angular.module("myModule",[]);


var myController = function($scope){
var employee = {
firstName:"Devid",
lastName:"Sharma",
gender:"male"
}
$scope.employee = employee;
}

myApp.controller("myController",myController);


var myApp2  = angular.module("myMaduleForImg",[]);

var myControllerImg = function($scope){
var Country = {
Name:"USA",
Capital:"Washington,D.C.",
flag:"images/babypic.jpg"
}
$scope.Country = Country;
}

myApp2.controller("myControllerImg",myControllerImg);



