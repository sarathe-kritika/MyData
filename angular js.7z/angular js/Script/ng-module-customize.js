////<reference path="angular.min.js"/>

var myApp = angular.module("myNg-Module",[]);


var myControllerNG = function($scope){
var student={
firstName:"DAVID",
lastName:"JORG",
CLASS:"XII"
}
$scope.student = student;
}

myApp.controller("myControllerNG",myControllerNG);

