//angular-custom-services.js
	
	
		
				
		var myController = function($scope,addServices){
		console.log("inside -- my controller");
			$scope.parformOp = function(input1,input2){
				$scope.output = addServices.calculation;
			}
		}		
	myApp.controller("myController",myController);
	