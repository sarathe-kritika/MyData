
//angular-own.js
		
		myApp.service("addServices",function(){
			return{
			    calculation: function(input1,input2){
				
					if(!input1 && !input2){
						return input1;
					}
					var output = "";
					output = input1+input2;
					console.log("addServices");
					return output;
				}
		    };
		});
	